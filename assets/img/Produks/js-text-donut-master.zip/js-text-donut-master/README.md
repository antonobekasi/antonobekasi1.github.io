# js-text-donut
A rotating donut in space

Original (and much more beautiful) + explanation:
https://www.a1k0n.net/2011/07/20/donut-math.html

Deobfuscation by @lexfridman C++ Source:
https://www.dropbox.com/s/79ga2m7p2bnj1ga/donut_deobfuscated.c?dl=0
